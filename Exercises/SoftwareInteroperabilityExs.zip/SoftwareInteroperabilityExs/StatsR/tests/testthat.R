library(testthat)
library(StatsR)

print("Running unit tests...")
testthat::test_dir('tests/testthat')

