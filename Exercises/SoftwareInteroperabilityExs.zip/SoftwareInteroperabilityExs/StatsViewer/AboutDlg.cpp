// Aboutdlg.cpp : Defines the class behaviors for the about dialog.
//
#include "pch.h"
#include "framework.h"

#include "AboutDlg.h"

//
// Construction
//
CAboutDlg::CAboutDlg() 
	: CDialogEx(IDD_ABOUTBOX)
{
}

//
// Data exchange
//
void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialogEx)
END_MESSAGE_MAP()

