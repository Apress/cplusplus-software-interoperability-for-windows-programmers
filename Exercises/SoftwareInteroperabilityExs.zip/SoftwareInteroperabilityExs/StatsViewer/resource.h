//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by StatsViewer.rc
//
#define IDD_ABOUTBOX                    100
#define IDD_STATSVIEWER_FORM            101
#define ID_STATUSBAR_PANE1              120
#define ID_STATUSBAR_PANE2              121
#define IDS_STATUS_PANE1                122
#define IDS_STATUS_PANE2                123
#define IDS_TOOLBAR_STANDARD            124
#define IDS_TOOLBAR_CUSTOMIZE           125
#define ID_VIEW_CUSTOMIZE               126
#define IDR_MAINFRAME                   128
#define IDR_MAINFRAME_256               129
#define IDR_StatsViewerTYPE             130
#define IDR_THEME_MENU                  200
#define ID_SET_STYLE                    201
#define ID_VIEW_APPLOOK_WIN_2000        205
#define ID_VIEW_APPLOOK_OFF_XP          206
#define ID_VIEW_APPLOOK_WIN_XP          207
#define ID_VIEW_APPLOOK_OFF_2003        208
#define ID_VIEW_APPLOOK_VS_2005         209
#define ID_VIEW_APPLOOK_VS_2008         210
#define ID_VIEW_APPLOOK_OFF_2007_BLUE   215
#define ID_VIEW_APPLOOK_OFF_2007_BLACK  216
#define ID_VIEW_APPLOOK_OFF_2007_SILVER 217
#define ID_VIEW_APPLOOK_OFF_2007_AQUA   218
#define ID_VIEW_APPLOOK_WINDOWS_7       219
#define IDS_EDIT_MENU                   306
#define IDD_DIALOG_DATASETS             311
#define IDD_TTEST_DATA_INPUT_DIALOG     313
#define IDD_FTEST_DATA_INPUT_DIALOG     314
#define IDR_RESULTS_POPUP               315
#define IDC_LISTCTRL_DATA               1001
#define IDC_STATIC_DATA                 1002
#define IDC_STATIC_RESULTS              1003
#define IDC_LISTCTRL_RESULTS            1004
#define IDC_LIST_DATASETS               1005
#define IDC_EDIT_MU0                    1006
#define IDC_EDIT_XBAR                   1007
#define IDC_EDIT_SX                     1008
#define IDC_EDIT_N                      1009
#define IDC_EDIT_SX1                    1010
#define IDC_EDIT_N1                     1011
#define IDC_EDIT_SX2                    1012
#define IDC_EDIT_N2                     1013
#define ID_STATISTICS_DESCRIPTIVE       32771
#define ID_STATISTICS_LINEARREGRESSION  32772
#define ID_STATISTICS_TESTS             32773
#define ID_STATISTICS_TESTS_TTEST       32774
#define ID_STATISTICS_TESTS_1SAMPLE     32775
#define ID_STATISTICS_TESTS_2SAMPLE     32776
#define ID_STATISTICS_CLEARDATA         32782
#define ID_TESTS_F                      32783
#define ID_STATISTICS_TESTS_FTEST       32784
#define ID_STATISTICS_TESTS_2SAMPLE_FTEST 32785
#define ID_POPUP_COPY                   32786
#define ID_BUTTON32788                  32788

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        316
#define _APS_NEXT_COMMAND_VALUE         32789
#define _APS_NEXT_CONTROL_VALUE         1010
#define _APS_NEXT_SYMED_VALUE           315
#endif
#endif
