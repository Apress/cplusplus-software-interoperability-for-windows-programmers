# -*- coding: utf-8 -*-

# The file __init__.py is what tells Python that the directory StatsPythonBoost/ is actually a Python package.